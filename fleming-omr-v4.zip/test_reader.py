"""
test_reader.py — Teste de integração do leitor OMR.

Gera um gabarito PDF, simula preenchimento, e valida a leitura.

Uso:
  python3 test_reader.py
  python3 test_reader.py /caminho/para/imagem_real.jpg
"""

import sys
import json
from pathlib import Path

from app.config import (
    get_all_bubble_centers_px,
    get_all_bubble_centers_mm,
    export_grid_json,
    TOTAL_QUESTIONS,
)


def test_config():
    """Valida que o config gera coordenadas para todas as 63 questões."""
    centers_mm = get_all_bubble_centers_mm()
    centers_px = get_all_bubble_centers_px()

    assert len(centers_mm) == TOTAL_QUESTIONS, (
        f"Esperado {TOTAL_QUESTIONS} questões, obtido {len(centers_mm)}"
    )
    assert len(centers_px) == TOTAL_QUESTIONS

    # Cada questão deve ter 4 alternativas
    for q in range(1, TOTAL_QUESTIONS + 1):
        assert q in centers_mm, f"Questão {q} faltando"
        assert len(centers_mm[q]) == 4, f"Q{q} tem {len(centers_mm[q])} alts"
        for alt in ["A", "B", "C", "D"]:
            assert alt in centers_mm[q], f"Q{q} falta alternativa {alt}"
            x, y = centers_mm[q][alt]
            assert 0 < x < 210, f"Q{q}{alt} x={x}mm fora da página"
            assert 0 < y < 297, f"Q{q}{alt} y={y}mm fora da página"

    print(f"✅ Config OK: {TOTAL_QUESTIONS} questões, 4 alternativas cada")
    print(f"   Q1.A  = {centers_px[1]['A']}px")
    print(f"   Q63.D = {centers_px[63]['D']}px")

    # Grid JSON
    grid = export_grid_json()
    print(f"   Grid JSON: {len(json.dumps(grid))} bytes")


def test_generator():
    """Gera um PDF de teste e valida."""
    from generator.sheet_generator import generate_sheet_for_student

    pdf_bytes = generate_sheet_for_student(
        template_type="ACAFE",
        student_id="1110",
        student_name="Julio Teste",
        student_sede="Florianópolis",
    )

    out = Path("output")
    out.mkdir(exist_ok=True)
    pdf_path = out / "teste_gabarito.pdf"
    pdf_path.write_bytes(pdf_bytes)
    print(f"✅ Gerador OK: {pdf_path} ({len(pdf_bytes)} bytes)")


def test_reader_on_image(image_path: str):
    """Testa o leitor numa imagem real."""
    from scanner.omr_reader import OMRReader

    reader = OMRReader()
    debug_path = str(Path(image_path).with_suffix(".debug.png"))
    result = reader.read(image_path, debug_path=debug_path)

    print(f"\n{'='*60}")
    print(f"Resultado para: {image_path}")
    print(f"{'='*60}")
    print(f"  Success:     {result.success}")
    print(f"  Template ID: {result.template_id}")
    print(f"  Student ID:  {result.student_id}")
    print(f"  Respostas:   {len(result.answers)}/{TOTAL_QUESTIONS}")
    print(f"  Erros:       {len(result.errors)}")

    if result.answers:
        print(f"\n  Respostas detectadas:")
        for q in sorted(result.answers.keys()):
            print(f"    Q{q}: {result.answers[q]}")

    if result.errors:
        print(f"\n  Erros:")
        for e in result.errors:
            print(f"    ⚠ {e}")

    print(f"\n  Debug salvo em: {debug_path}")


if __name__ == "__main__":
    test_config()
    test_generator()

    if len(sys.argv) > 1:
        test_reader_on_image(sys.argv[1])
    else:
        print("\n💡 Para testar com imagem real:")
        print("   python3 test_reader.py /caminho/para/gabarito.jpg")
