"""
config.py — Geometria central do gabarito Fleming OMR.

Este arquivo é a ÚNICA fonte de verdade para posições de bolhas.
Tanto o gerador de PDF quanto o scanner importam daqui.
Se mudar aqui, muda em tudo.

Unidades base: milímetros (mm).
Conversão para pixels: px = mm * DPI / 25.4
"""

from typing import Dict, Tuple

# =============================================================================
# PÁGINA
# =============================================================================
PAGE_W_MM = 210.0          # A4 largura
PAGE_H_MM = 297.0          # A4 altura
REFERENCE_DPI = 300        # DPI de referência do warp/scan

# =============================================================================
# FIDUCIAIS (quadrados pretos nos 4 cantos)
# =============================================================================
FIDUCIAL_SIZE_MM = 8.0     # lado do quadrado
FIDUCIAL_MARGIN_MM = 5.0   # distância da borda da página ao centro do fiducial

# Centros dos 4 fiduciais em mm (x, y) — usado para warp de perspectiva
FIDUCIAL_CENTERS_MM = [
    (FIDUCIAL_MARGIN_MM + FIDUCIAL_SIZE_MM / 2,
     FIDUCIAL_MARGIN_MM + FIDUCIAL_SIZE_MM / 2),                                   # top-left
    (PAGE_W_MM - FIDUCIAL_MARGIN_MM - FIDUCIAL_SIZE_MM / 2,
     FIDUCIAL_MARGIN_MM + FIDUCIAL_SIZE_MM / 2),                                   # top-right
    (FIDUCIAL_MARGIN_MM + FIDUCIAL_SIZE_MM / 2,
     PAGE_H_MM - FIDUCIAL_MARGIN_MM - FIDUCIAL_SIZE_MM / 2),                       # bottom-left
    (PAGE_W_MM - FIDUCIAL_MARGIN_MM - FIDUCIAL_SIZE_MM / 2,
     PAGE_H_MM - FIDUCIAL_MARGIN_MM - FIDUCIAL_SIZE_MM / 2),                       # bottom-right
]

# =============================================================================
# CABEÇALHO
# =============================================================================
HEADER_HEIGHT_MM = 78.0    # altura da área de cabeçalho (nome, sede, QR, instruções)

# =============================================================================
# BOLHAS
# =============================================================================
BUBBLE_RADIUS_MM = 3.5     # raio de cada bolha
BUBBLE_SPACING_X_MM = 8.5  # distância horizontal entre centros (A→B, B→C, etc.)
ROW_SPACING_Y_MM = 8.0     # distância vertical entre linhas de questões

# =============================================================================
# LAYOUT DOS BLOCOS — ACAFE 63 questões
# =============================================================================
TOTAL_QUESTIONS = 63
ALTERNATIVES = ["A", "B", "C", "D"]
QUESTIONS_PER_BLOCK = 20   # máximo por bloco (último bloco pode ter menos)

# Posição X (mm) do centro da alternativa A de cada bloco
# Calculado para distribuir uniformemente na largura útil da página
_MARGIN_LEFT_MM = 29.0     # margem esquerda até o centro da 1ª bolha
_BLOCK_PITCH_MM = 45.0     # distância entre inícios de blocos consecutivos

BLOCK_A_X_MM = [
    _MARGIN_LEFT_MM + i * _BLOCK_PITCH_MM
    for i in range(4)
]
# Resultado: [15.0, 60.0, 105.0, 150.0] mm

# Posição Y (mm) da primeira linha de cada bloco (Q1, Q21, Q41, Q61)
FIRST_ROW_Y_MM = HEADER_HEIGHT_MM + FIDUCIAL_SIZE_MM + ROW_SPACING_Y_MM
# ≈ 32 + 8 + 8 = 48mm do topo

# Quantas questões em cada bloco
BLOCK_QUESTION_COUNTS = [20, 20, 20, 3]

# =============================================================================
# THRESHOLDS DE LEITURA
# =============================================================================
FILLED_THRESHOLD = 0.35     # acima disso → marcada
AMBIGUOUS_THRESHOLD = 0.80  # se 2ª melhor > melhor * isso → dupla marcação

# =============================================================================
# FUNÇÕES DE CONVERSÃO
# =============================================================================

def mm_to_px(mm: float, dpi: int = REFERENCE_DPI) -> float:
    """Converte milímetros para pixels."""
    return mm * dpi / 25.4


def px_to_mm(px: float, dpi: int = REFERENCE_DPI) -> float:
    """Converte pixels para milímetros."""
    return px * 25.4 / dpi


# =============================================================================
# GERADOR DE COORDENADAS — a função principal
# =============================================================================

def get_all_bubble_centers_mm() -> Dict[int, Dict[str, Tuple[float, float]]]:
    """
    Retorna as coordenadas (x_mm, y_mm) do centro de cada bolha.

    Retorno: {
        1:  {"A": (15.0, 48.0), "B": (23.5, 48.0), "C": (32.0, 48.0), "D": (40.5, 48.0)},
        2:  {"A": (15.0, 56.0), "B": (23.5, 56.0), ...},
        ...
        63: {"A": (150.0, 64.0), ...}
    }
    """
    centers: Dict[int, Dict[str, Tuple[float, float]]] = {}
    q_num = 1

    for block_idx, count in enumerate(BLOCK_QUESTION_COUNTS):
        base_x = BLOCK_A_X_MM[block_idx]

        for row in range(count):
            y = FIRST_ROW_Y_MM + row * ROW_SPACING_Y_MM
            alts = {}
            for alt_idx, alt in enumerate(ALTERNATIVES):
                x = base_x + alt_idx * BUBBLE_SPACING_X_MM
                alts[alt] = (round(x, 2), round(y, 2))
            centers[q_num] = alts
            q_num += 1

    return centers


def get_all_bubble_centers_px(
    dpi: int = REFERENCE_DPI,
) -> Dict[int, Dict[str, Tuple[int, int]]]:
    """
    Igual a get_all_bubble_centers_mm(), mas em pixels inteiros.

    Usado pelo scanner após o warp (imagem normalizada para DPI de referência).
    """
    mm_centers = get_all_bubble_centers_mm()
    px_centers: Dict[int, Dict[str, Tuple[int, int]]] = {}

    for q_num, alts in mm_centers.items():
        px_alts = {}
        for alt, (x_mm, y_mm) in alts.items():
            px_alts[alt] = (int(mm_to_px(x_mm, dpi)), int(mm_to_px(y_mm, dpi)))
        px_centers[q_num] = px_alts

    return px_centers


def get_warp_dimensions(dpi: int = REFERENCE_DPI) -> Tuple[int, int]:
    """Dimensões da imagem warped em pixels."""
    return (int(mm_to_px(PAGE_W_MM, dpi)), int(mm_to_px(PAGE_H_MM, dpi)))


def get_fiducial_corners_px(dpi: int = REFERENCE_DPI) -> list:
    """Centros dos 4 fiduciais em pixels (para warp de perspectiva)."""
    return [
        (int(mm_to_px(x, dpi)), int(mm_to_px(y, dpi)))
        for x, y in FIDUCIAL_CENTERS_MM
    ]


# =============================================================================
# EXPORTAÇÃO COMO JSON (para debug / QR / banco de dados)
# =============================================================================

def export_grid_json(dpi: int = REFERENCE_DPI) -> dict:
    """Exporta o grid completo como dicionário serializável."""
    return {
        "dpi": dpi,
        "page_size_px": list(get_warp_dimensions(dpi)),
        "total_questions": TOTAL_QUESTIONS,
        "alternatives": ALTERNATIVES,
        "bubble_radius_px": int(mm_to_px(BUBBLE_RADIUS_MM, dpi)),
        "fiducials_px": get_fiducial_corners_px(dpi),
        "questions": {
            str(q): {alt: list(pos) for alt, pos in alts.items()}
            for q, alts in get_all_bubble_centers_px(dpi).items()
        },
    }


# =============================================================================
# VALIDAÇÃO RÁPIDA (executar diretamente para conferir)
# =============================================================================
if __name__ == "__main__":
    centers = get_all_bubble_centers_px()
    print(f"Total de questões mapeadas: {len(centers)}")
    for q in [1, 21, 41, 61, 63]:
        if q in centers:
            print(f"  Q{q}: {centers[q]}")

    import json
    grid = export_grid_json()
    print(f"\nGrid JSON ({len(json.dumps(grid))} bytes)")
    print(f"  Fiduciais: {grid['fiducials_px']}")
    print(f"  Raio bolha: {grid['bubble_radius_px']}px")
