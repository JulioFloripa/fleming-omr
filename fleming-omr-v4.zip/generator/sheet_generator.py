"""
sheet_generator.py — Gerador de gabaritos PDF.

Usa as mesmas coordenadas de app.config para garantir que
o scanner leia exatamente nas posições corretas.

ReportLab usa pontos (1pt = 1/72 in = 0.3528mm) com origem em BOTTOM-LEFT.
config.py usa mm com origem em TOP-LEFT.
A conversão é: y_reportlab = PAGE_H_MM - y_config (em mm), depois mm→pt.
"""

import io
import json
from typing import Optional

import qrcode
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

from app.config import (
    ALTERNATIVES,
    BLOCK_A_X_MM,
    BLOCK_QUESTION_COUNTS,
    BUBBLE_RADIUS_MM,
    BUBBLE_SPACING_X_MM,
    FIDUCIAL_CENTERS_MM,
    FIDUCIAL_SIZE_MM,
    FIRST_ROW_Y_MM,
    HEADER_HEIGHT_MM,
    PAGE_H_MM,
    PAGE_W_MM,
    ROW_SPACING_Y_MM,
    TOTAL_QUESTIONS,
    get_all_bubble_centers_mm,
)

# Conversões
_PT_PER_MM = 72.0 / 25.4  # ≈ 2.835


def _mm_to_pt(val: float) -> float:
    return val * _PT_PER_MM


def _y_flip(y_mm: float) -> float:
    """Converte Y de top-left (config) para bottom-left (ReportLab), em mm."""
    return PAGE_H_MM - y_mm


# =============================================================================
# GERADOR PRINCIPAL
# =============================================================================


def generate_sheet_for_student(
    template_type: str = "ACAFE",
    student_id: str = "",
    student_name: str = "",
    student_sede: str = "",
    template_id: Optional[str] = None,
) -> bytes:
    """
    Gera um PDF de gabarito para um aluno.

    Retorna bytes do PDF.
    """
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)

    # ------------------------------------------------------------------
    # 1. FIDUCIAIS (quadrados pretos nos cantos)
    # ------------------------------------------------------------------
    half = FIDUCIAL_SIZE_MM / 2
    for fx, fy in FIDUCIAL_CENTERS_MM:
        x_pt = _mm_to_pt(fx - half)
        y_pt = _mm_to_pt(_y_flip(fy) - half)
        c.setFillColorRGB(0, 0, 0)
        c.rect(
            x_pt, y_pt,
            _mm_to_pt(FIDUCIAL_SIZE_MM),
            _mm_to_pt(FIDUCIAL_SIZE_MM),
            stroke=0, fill=1,
        )

    # ------------------------------------------------------------------
    # 2. CABEÇALHO
    # ------------------------------------------------------------------
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(
        _mm_to_pt(PAGE_W_MM / 2),
        _mm_to_pt(_y_flip(12)),
        f"Gabarito — {template_type}",
    )

    c.setFont("Helvetica", 10)
    c.drawString(_mm_to_pt(15), _mm_to_pt(_y_flip(20)), f"Aluno: {student_name}")
    c.drawString(_mm_to_pt(15), _mm_to_pt(_y_flip(25)), f"Sede: {student_sede}")
    c.drawString(
        _mm_to_pt(120), _mm_to_pt(_y_flip(20)), f"Matrícula: {student_id}"
    )

    # ------------------------------------------------------------------
    # 3. QR CODE
    # ------------------------------------------------------------------
    qr_data = json.dumps({
        "tid": template_id or f"{template_type}_default",
        "sid": student_id,
    })
    qr_img = qrcode.make(qr_data, box_size=3, border=1)
    qr_buf = io.BytesIO()
    qr_img.save(qr_buf, format="PNG")
    qr_buf.seek(0)

    from reportlab.lib.utils import ImageReader

    qr_size_mm = 18
    c.drawImage(
        ImageReader(qr_buf),
        _mm_to_pt(PAGE_W_MM - 15 - qr_size_mm),
        _mm_to_pt(_y_flip(10) - qr_size_mm),
        width=_mm_to_pt(qr_size_mm),
        height=_mm_to_pt(qr_size_mm),
    )

    # ------------------------------------------------------------------
    # 4. NÚMEROS DAS QUESTÕES (à esquerda de cada bloco)
    # ------------------------------------------------------------------
    c.setFont("Helvetica", 7)
    c.setFillColorRGB(0.3, 0.3, 0.3)

    q_num = 1
    for block_idx, count in enumerate(BLOCK_QUESTION_COUNTS):
        base_x = BLOCK_A_X_MM[block_idx]

        for row in range(count):
            y_mm = FIRST_ROW_Y_MM + row * ROW_SPACING_Y_MM
            # Número da questão à esquerda da alternativa A
            c.drawRightString(
                _mm_to_pt(base_x - 3),
                _mm_to_pt(_y_flip(y_mm)) - 2,
                str(q_num),
            )
            q_num += 1

    # ------------------------------------------------------------------
    # 5. LETRAS DAS ALTERNATIVAS (acima de cada coluna)
    # ------------------------------------------------------------------
    c.setFont("Helvetica-Bold", 7)
    c.setFillColorRGB(0.2, 0.2, 0.2)
    label_y_mm = FIRST_ROW_Y_MM - ROW_SPACING_Y_MM * 0.7

    for block_idx in range(len(BLOCK_QUESTION_COUNTS)):
        base_x = BLOCK_A_X_MM[block_idx]
        for alt_idx, alt in enumerate(ALTERNATIVES):
            x_mm = base_x + alt_idx * BUBBLE_SPACING_X_MM
            c.drawCentredString(
                _mm_to_pt(x_mm),
                _mm_to_pt(_y_flip(label_y_mm)),
                alt,
            )

    # ------------------------------------------------------------------
    # 6. BOLHAS (círculos vazios nas posições exatas do config)
    # ------------------------------------------------------------------
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.6)
    c.setFillColorRGB(1, 1, 1)

    centers_mm = get_all_bubble_centers_mm()
    for q, alts in centers_mm.items():
        for alt, (x_mm, y_mm) in alts.items():
            c.circle(
                _mm_to_pt(x_mm),
                _mm_to_pt(_y_flip(y_mm)),
                _mm_to_pt(BUBBLE_RADIUS_MM),
                stroke=1, fill=1,
            )

    # ------------------------------------------------------------------
    # 7. LINHAS SEPARADORAS ENTRE BLOCOS
    # ------------------------------------------------------------------
    c.setStrokeColorRGB(0.8, 0.8, 0.8)
    c.setLineWidth(0.3)

    for block_idx in range(1, len(BLOCK_QUESTION_COUNTS)):
        # Linha vertical entre blocos
        sep_x_mm = (
            BLOCK_A_X_MM[block_idx - 1]
            + (len(ALTERNATIVES) - 1) * BUBBLE_SPACING_X_MM
            + BLOCK_A_X_MM[block_idx]
        ) / 2
        y_top = FIRST_ROW_Y_MM - ROW_SPACING_Y_MM
        y_bot = FIRST_ROW_Y_MM + 19 * ROW_SPACING_Y_MM + ROW_SPACING_Y_MM
        c.line(
            _mm_to_pt(sep_x_mm), _mm_to_pt(_y_flip(y_top)),
            _mm_to_pt(sep_x_mm), _mm_to_pt(_y_flip(y_bot)),
        )

    # ------------------------------------------------------------------
    # FINALIZAR
    # ------------------------------------------------------------------
    c.showPage()
    c.save()
    return buf.getvalue()
