"""
omr_reader.py — Leitor OMR por coordenadas absolutas.

Estratégia:
  1. Lê QR Code (pyzbar → fallback OpenCV).
  2. Warp de perspectiva usando detecção do contorno da página.
  3. Threshold adaptativo na imagem warped.
  4. Para cada questão, amostra o preenchimento nas coordenadas CONHECIDAS.
  5. Decide: marcada, vazia ou dupla marcação.

Zero HoughCircles. Zero detecção de contornos para bolhas.
O gerador e o scanner compartilham a mesma geometria via app.config.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from app.config import (
    ALTERNATIVES,
    AMBIGUOUS_THRESHOLD,
    BUBBLE_RADIUS_MM,
    FILLED_THRESHOLD,
    TOTAL_QUESTIONS,
    get_all_bubble_centers_px,
    get_warp_dimensions,
    mm_to_px,
)


# =============================================================================
# MODELOS
# =============================================================================


@dataclass
class OMRResult:
    """Resultado da leitura de um gabarito."""

    success: bool
    template_id: Optional[str] = None
    student_id: Optional[str] = None
    answers: dict = field(default_factory=dict)
    errors: list = field(default_factory=list)
    raw_data: Optional[str] = None


# =============================================================================
# QR CODE
# =============================================================================

try:
    from pyzbar.pyzbar import decode as pyzbar_decode

    _PYZBAR_OK = True
except ImportError:
    _PYZBAR_OK = False


def decode_qr(gray: np.ndarray) -> Optional[dict]:
    """Tenta decodificar QR Code da imagem (pyzbar → OpenCV fallback)."""
    if _PYZBAR_OK:
        for obj in pyzbar_decode(gray):
            try:
                return json.loads(obj.data.decode())
            except Exception:
                pass

    det = cv2.QRCodeDetector()
    ok, info, _, _ = det.detectAndDecodeMulti(gray)
    if ok:
        for s in info:
            if s:
                try:
                    return json.loads(s)
                except Exception:
                    pass
    return None


# =============================================================================
# WARP DE PERSPECTIVA
# =============================================================================


def _order_points(pts: np.ndarray) -> np.ndarray:
    """Ordena 4 pontos: TL, TR, BR, BL."""
    rect = np.zeros((4, 2), dtype=np.float32)
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]   # top-left
    rect[2] = pts[np.argmax(s)]   # bottom-right
    d = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(d)]   # top-right
    rect[3] = pts[np.argmax(d)]   # bottom-left
    return rect


def _find_page_contour(gray: np.ndarray) -> Optional[np.ndarray]:
    """Encontra o contorno retangular da folha na imagem."""
    h, w = gray.shape
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Tenta com diferentes parâmetros de Canny
    for lo, hi in [(30, 100), (50, 150), (20, 80)]:
        edges = cv2.Canny(blurred, lo, hi)
        edges = cv2.dilate(edges, None, iterations=2)
        cnts, _ = cv2.findContours(
            edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        cnts = sorted(cnts, key=cv2.contourArea, reverse=True)

        for cnt in cnts[:10]:
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
            if len(approx) != 4:
                continue
            area = cv2.contourArea(approx)
            if area < h * w * 0.15:
                continue
            return approx.reshape(4, 2)

    return None


def warp_to_standard(img: np.ndarray, gray: np.ndarray) -> np.ndarray:
    """
    Aplica warp de perspectiva para normalizar a imagem.

    Tenta detectar o contorno da página. Se não encontrar, faz resize direto.
    O resultado tem as dimensões padrão definidas em config (2480 x 3507 @ 300 DPI).
    """
    warp_w, warp_h = get_warp_dimensions()
    dst = np.float32([[0, 0], [warp_w, 0], [warp_w, warp_h], [0, warp_h]])

    pts = _find_page_contour(gray)
    if pts is not None:
        src = _order_points(pts.astype(np.float32))
        M = cv2.getPerspectiveTransform(src, dst)
        return cv2.warpPerspective(img, M, (warp_w, warp_h))

    # Fallback: resize simples (funciona com scans retos)
    return cv2.resize(img, (warp_w, warp_h))


# =============================================================================
# LEITOR PRINCIPAL
# =============================================================================


class OMRReader:
    """Leitor OMR por coordenadas absolutas."""

    def __init__(
        self,
        fill_threshold: float = FILLED_THRESHOLD,
        ambiguous_ratio: float = AMBIGUOUS_THRESHOLD,
    ):
        self.fill_threshold = fill_threshold
        self.ambiguous_ratio = ambiguous_ratio
        self.radius_px = int(mm_to_px(BUBBLE_RADIUS_MM) * 1.4)
        self.centers = get_all_bubble_centers_px()

    def read(
        self,
        image_path: str,
        debug_path: Optional[str] = None,
    ) -> OMRResult:
        """
        Lê um gabarito escaneado e retorna as respostas detectadas.

        Args:
            image_path: caminho da imagem (JPG, PNG ou convertido de PDF).
            debug_path: se fornecido, salva imagem anotada para debug.

        Returns:
            OMRResult com answers={1: "A", 2: "C", ...}
        """
        img = cv2.imread(str(image_path))
        if img is None:
            return OMRResult(
                success=False,
                errors=[f"Não foi possível abrir: {image_path}"],
            )

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 1. QR Code (antes do warp — imagem original tem mais resolução)
        qr = decode_qr(gray)
        tid = (qr.get("tid") or qr.get("template_id")) if qr else None
        sid = (qr.get("sid") or qr.get("student_id")) if qr else None

        # 2. Warp para dimensões padrão
        warped = warp_to_standard(img, gray)
        warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)

        # 3. Threshold adaptativo
        blurred = cv2.GaussianBlur(warped_gray, (3, 3), 0)
        thresh = cv2.adaptiveThreshold(
            blurred, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            31, 8,
        )
        # Limpeza morfológica
        kernel = np.ones((3, 3), np.uint8)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

        # 4. Leitura direta nas coordenadas conhecidas
        answers = {}
        errors = []
        dbg = warped.copy() if debug_path else None

        for q_num, alts in self.centers.items():
            fills = {}

            for alt, (cx, cy) in alts.items():
                fill_ratio = self._sample_fill(thresh, cx, cy)
                fills[alt] = fill_ratio

                # Debug annotations
                if dbg is not None:
                    color = (0, 255, 0)  # verde = vazia
                    if fill_ratio > self.fill_threshold:
                        color = (0, 0, 255)  # vermelho = marcada
                    cv2.circle(dbg, (cx, cy), self.radius_px, color, 2)
                    cv2.circle(dbg, (cx, cy), 2, (255, 0, 0), -1)
                    cv2.putText(
                        dbg,
                        f"{fill_ratio:.2f}",
                        (cx - 15, cy - self.radius_px - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1,
                    )

            # Decisão
            sorted_fills = sorted(
                fills.items(), key=lambda x: x[1], reverse=True
            )
            best_alt, best_fill = sorted_fills[0]
            second_fill = sorted_fills[1][1] if len(sorted_fills) > 1 else 0.0

            # Questão em branco
            if best_fill < self.fill_threshold:
                continue

            # Dupla marcação
            if second_fill > best_fill * self.ambiguous_ratio:
                errors.append(
                    f"Q{q_num}: possível dupla marcação "
                    f"({sorted_fills[0][0]}={best_fill:.2f}, "
                    f"{sorted_fills[1][0]}={second_fill:.2f})"
                )
                continue

            answers[q_num] = best_alt

        # 5. Debug output
        if dbg is not None and debug_path:
            cv2.imwrite(str(debug_path), dbg)

        return OMRResult(
            success=len(answers) > 0,
            template_id=tid,
            student_id=sid,
            answers=answers,
            errors=errors,
            raw_data=json.dumps(qr) if qr else None,
        )

    def _sample_fill(
        self,
        thresh: np.ndarray,
        cx: int,
        cy: int,
    ) -> float:
        """
        Calcula a fração de pixels marcados numa máscara circular
        ao redor de (cx, cy) com raio self.radius_px.
        """
        h, w = thresh.shape

        # Clamp para não sair da imagem
        if cx < 0 or cy < 0 or cx >= w or cy >= h:
            return 0.0

        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(mask, (cx, cy), self.radius_px, 255, -1)
        masked = cv2.bitwise_and(thresh, thresh, mask=mask)
        total_white = cv2.countNonZero(masked)
        area = cv2.countNonZero(mask)

        if area == 0:
            return 0.0

        return total_white / float(area)
