"""
main.py — API REST Fleming OMR.

Endpoints:
  GET  /health          → status
  POST /scan-batch      → leitura de gabaritos (multipart)
  POST /generate-batch  → geração de PDFs (JSON)
  GET  /grid            → exporta grid de coordenadas (debug)
"""

import io
import json
import os
import tempfile
import zipfile
from typing import Optional

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

from app.config import TOTAL_QUESTIONS, ALTERNATIVES, export_grid_json
from scanner.omr_reader import OMRReader

app = FastAPI(
    title="Fleming OMR API",
    version="4.0.0",
    description="Leitura e geração de gabaritos — Colégio Fleming",
)

# Token de autenticação
API_TOKEN = os.environ.get("FLEMING_API_TOKEN", "fleming-token-2025-acafe")


def _check_token(token: Optional[str]):
    """Verifica token de autenticação."""
    if not token or token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Token inválido")


# =============================================================================
# HEALTH
# =============================================================================


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "Fleming OMR API",
        "version": "4.0.0",
        "approach": "position-based reading",
        "total_questions": TOTAL_QUESTIONS,
        "alternatives": ALTERNATIVES,
    }


# =============================================================================
# GRID (debug)
# =============================================================================


@app.get("/grid")
async def grid(x_fleming_token: Optional[str] = Header(None)):
    _check_token(x_fleming_token)
    return export_grid_json()


# =============================================================================
# SCAN BATCH
# =============================================================================


@app.post("/scan-batch")
async def scan_batch(
    files: list[UploadFile] = File(...),
    config: str = Form("{}"),
    x_fleming_token: Optional[str] = Header(None),
):
    """
    Recebe imagens de gabaritos e retorna respostas detectadas.

    FormData:
      - files: imagens (JPG, PNG)
      - config: JSON opcional {"total_questions": 63, "alternatives": ["A","B","C","D"]}
    """
    _check_token(x_fleming_token)

    try:
        cfg = json.loads(config) if config else {}
    except json.JSONDecodeError:
        cfg = {}

    reader = OMRReader(
        fill_threshold=cfg.get("fill_threshold", 0.35),
    )

    results = []
    for f in files:
        data = await f.read()
        if not data:
            results.append({
                "scan_id": f.filename,
                "success": False,
                "errors": ["Arquivo vazio"],
            })
            continue

        # Converter PDF para imagem se necessário
        actual_data = data
        if f.filename and f.filename.lower().endswith(".pdf"):
            actual_data = _convert_pdf_to_png(data)
            if actual_data is None:
                results.append({
                    "scan_id": f.filename,
                    "success": False,
                    "errors": ["Falha ao converter PDF para imagem"],
                })
                continue

        # Salvar temporariamente e processar
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(actual_data)
            tmp_path = tmp.name

        try:
            debug_path = tmp_path.replace(".png", "_debug.png")
            result = reader.read(tmp_path, debug_path=debug_path)

            results.append({
                "scan_id": f.filename,
                "success": result.success,
                "template_id": result.template_id,
                "student_id": result.student_id,
                "detected_answers": {
                    str(k): v for k, v in result.answers.items()
                },
                "total_detected": len(result.answers),
                "total_expected": TOTAL_QUESTIONS,
                "errors": result.errors,
            })
        finally:
            _safe_remove(tmp_path)
            _safe_remove(debug_path)

    return {"results": results}


# =============================================================================
# SCAN BATCH URL (recebe URLs em vez de arquivos)
# =============================================================================


class ScanURLItem(BaseModel):
    scan_id: str
    image_url: str


class ScanURLRequest(BaseModel):
    template: dict = {}
    scans: list[ScanURLItem] = []


@app.post("/scan-batch-url")
async def scan_batch_url(
    body: ScanURLRequest,
    x_fleming_token: Optional[str] = Header(None),
):
    """Recebe URLs de imagens e retorna respostas detectadas."""
    _check_token(x_fleming_token)

    import httpx

    reader = OMRReader()
    results = []

    async with httpx.AsyncClient(timeout=30) as client:
        for scan in body.scans:
            try:
                resp = await client.get(scan.image_url)
                resp.raise_for_status()
                data = resp.content
            except Exception as e:
                results.append({
                    "scan_id": scan.scan_id,
                    "success": False,
                    "errors": [f"Falha ao baixar imagem: {e}"],
                })
                continue

            with tempfile.NamedTemporaryFile(
                suffix=".png", delete=False
            ) as tmp:
                tmp.write(data)
                tmp_path = tmp.name

            try:
                result = reader.read(tmp_path)
                results.append({
                    "scan_id": scan.scan_id,
                    "success": result.success,
                    "template_id": result.template_id,
                    "student_id": result.student_id,
                    "detected_answers": {
                        str(k): v for k, v in result.answers.items()
                    },
                    "total_detected": len(result.answers),
                    "total_expected": TOTAL_QUESTIONS,
                    "errors": result.errors,
                })
            finally:
                _safe_remove(tmp_path)

    return {"results": results}


# =============================================================================
# GENERATE BATCH
# =============================================================================


class StudentInfo(BaseModel):
    id: str
    name: str
    sede: str = ""


class GenerateBatchRequest(BaseModel):
    template_type: str = "ACAFE"
    students: list[StudentInfo] = []


@app.post("/generate-batch")
async def generate_batch(
    body: GenerateBatchRequest,
    x_fleming_token: Optional[str] = Header(None),
):
    """Gera gabaritos PDF em ZIP para uma lista de alunos."""
    _check_token(x_fleming_token)

    from generator.sheet_generator import generate_sheet_for_student

    if not body.students:
        raise HTTPException(400, "Lista de alunos vazia")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for student in body.students:
            pdf_bytes = generate_sheet_for_student(
                template_type=body.template_type,
                student_id=student.id,
                student_name=student.name,
                student_sede=student.sede,
            )
            filename = (
                f"gabarito_{student.id}_{student.name.replace(' ', '_')}.pdf"
            )
            zf.writestr(filename, pdf_bytes)

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": "attachment; filename=gabaritos.zip"
        },
    )


# =============================================================================
# HELPERS
# =============================================================================


def _convert_pdf_to_png(data: bytes) -> Optional[bytes]:
    """Converte primeira página de PDF para PNG bytes."""
    try:
        from pdf2image import convert_from_bytes

        images = convert_from_bytes(data, dpi=300, first_page=1, last_page=1)
        if not images:
            return None
        buf = io.BytesIO()
        images[0].save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return None


def _safe_remove(path: str):
    """Remove arquivo ignorando erros."""
    try:
        os.unlink(path)
    except OSError:
        pass
