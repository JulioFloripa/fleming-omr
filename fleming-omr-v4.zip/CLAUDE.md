# CLAUDE.md — Briefing do Projeto Fleming OMR

## O que é
API Python (FastAPI) de leitura óptica de gabaritos (OMR) para o Colégio Fleming.
Roda no Google Cloud Run. Integra com frontend Lovable (React + Supabase).

## Arquitetura v4 — Leitura por Coordenadas Absolutas

O scanner NÃO detecta bolhas (sem HoughCircles, sem contorno).
Em vez disso, usa as coordenadas exatas de cada bolha, definidas em `app/config.py`.
O gerador de PDF usa as MESMAS coordenadas. Um único source of truth.

```
app/config.py               → Geometria central (mm → px)
                             ↙              ↘
generator/sheet_generator.py     scanner/omr_reader.py
(gera PDF com bolhas em X,Y)     (lê preenchimento em X,Y)
                             ↘              ↙
                              api/main.py → FastAPI REST
```

## Estrutura
```
app/config.py                → Constantes físicas + get_all_bubble_centers_px()
scanner/omr_reader.py        → Leitor OMR (warp + leitura direta)
api/main.py                  → FastAPI endpoints REST
generator/sheet_generator.py → Gerador de PDFs (reportlab + qrcode)
test_reader.py               → Teste de integração
Dockerfile                   → Deploy no Cloud Run
requirements.txt             → Dependências Python
```

## Cloud Run
- URL: https://fleming-omr-661476378860.southamerica-east1.run.app
- Token: Header `X-Fleming-Token: fleming-token-2025-acafe`
- Projeto GCP: corretorflemingv2
- Região: southamerica-east1

## Deploy
```bash
bash deploy.sh
```

## Teste
```bash
# Health
curl -s https://fleming-omr-661476378860.southamerica-east1.run.app/health \
  -H "X-Fleming-Token: fleming-token-2025-acafe"

# Grid de coordenadas (debug)
curl -s https://fleming-omr-661476378860.southamerica-east1.run.app/grid \
  -H "X-Fleming-Token: fleming-token-2025-acafe" | python3 -m json.tool

# Scan com imagem
curl -s -X POST \
  -H "X-Fleming-Token: fleming-token-2025-acafe" \
  -F "files=@imagem.jpg" \
  https://fleming-omr-661476378860.southamerica-east1.run.app/scan-batch | python3 -m json.tool

# Teste local
python3 test_reader.py
python3 test_reader.py /caminho/imagem.jpg
```

## Constantes físicas (em app/config.py)
- PAGE: 210 x 297 mm (A4), DPI referência: 300
- FIDUCIAL_SIZE = 8mm, FIDUCIAL_MARGIN = 5mm
- BUBBLE_RADIUS = 3.5mm
- BUBBLE_SPACING_X = 8.5mm, ROW_SPACING_Y = 8.0mm
- HEADER_HEIGHT = 32mm
- 4 blocos: [20, 20, 20, 3] questões
- FILLED_THRESHOLD = 0.35

## Convenções
- Python 3.11, type hints, docstrings em português
- O scanner aceita path de arquivo
- OMRResult.answers é dict[int, str] → {1: "A", 2: "C", ...}
